### Singles Match
#### Adrian Waters vs KC Shore

