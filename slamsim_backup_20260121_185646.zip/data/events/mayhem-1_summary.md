### Singles Match
#### Fitzgerald vs Lenny Dennis



---

### Singles Match
#### Don Real vs Rick Walker



---

### Singles Match
#### Extreme Randy vs Jim Brady



---

### Tag-Team Match
#### The Mad Dogs vs Chris Baer, Eric Baer

The first televised match for WMA saw the Mad Dogs face Da Bad News Baers. Eric and Chris Baer stood their ground as Bark and Bite charged the ring, but it did them little good. The Mad Dogs threw Chris to the floor and hit Eric with their spiked powerbomb, “The Dog Pound,” and they scored the pinfall.

---

Backstage, Brenda McHale interviewed WMA GM Pete Floyd, who announced that, starting in May, there would be tournaments to crown the first WMA Heavyweight, WMA Women’s, and WMA Tag-Team Champions. He also mentioned that there would be more signings as WMA expanded.

Afterwards, there was a pre-recorded video package of Evander Flagg and his charges (Alexi Chambers, Autumn Chambers, Johnny Destruction, and Scott Ashton.

John Thompson interviewed Michael King and Jamey Kingston. The focus was on Kingston, who declared he would be the first WMA Heavyweight Champion.


---

### Singles Match
#### Amy D vs Mandy Matthews

Two young women made their pro wrestling television debuts as Mandy Matthews faced Amy D. The match started out with fast-paced chain wrestling, but soon broke down into a brawl between these two young stars. Matthews was victorious, causing Amy D to tap out to the Maniac Rack camel clutch.


---

Brenda McHale interviewed The Mad Dogs, who proclaimed there was no tag-team on the WMA roster who could defeat them. They said they would be the first WMA Tag-Team Champions.

---

### Singles Match
#### Apalachi vs Tom Ham

The next match was nothing more than a squash as “The Definition of Power” Apalachi took on Tom Ham. Apalachi hit Ham with “The Ram” (a spear) followed by “Powerdown” (a vertebreaker), and he got the 1-2-3. After the match, at the urging of his manager, Rudy Fresno, Apalachi hit Ham with two more Powerdowns.

---

Backstage, was a segment featuring the Happy Faces on their happy face yellow golf carts, generally annoying WMA staff. They eventually approached The Sacred Dragons and Rudy Fresno. The two teams exchanged a few insults, then the scene switched to John Thompson, who interviewed Amber Sloane. After this interview, Brenda McHale interviewed TJ Valentine.


---

### Singles Match
#### Anastasia Phoenix vs Autumn Chambers

Autumn Chambers, accompanied by Evander Flagg, faced off against Anastasia Phoenix. Phoenix had the early advantage with hip tosses, drop kicks, and arm drags. A couple of close pinfalls and Chambers bailed out to consult with Flagg. Chambers slowed down the pace and took over from here. In the end, however, Anastasia reversed an Irish whip and hit a belly-to-belly suplex, getting the three count. After having her arm raised in victory, Phoenix was attacked from behind by Autumn. Chambers and Flagg double-teamed Anastasia, leaving her lying in the center of the ring.

---

Backstage, Brenda McHale interviewed Max Dynamite and “The Monster” Payne. John Thompson interviewed KC Shore and Joe Shore, who expressed disgust over the actions of both Apalachi and Autumn Chambers earlier in the show. Joe discussed his match later tonight, and KC discussed the upcoming tournaments.

---

### Women's 3-Way Match
#### Amber Sloane vs Apryl Raser vs Kiara Haddad

The next match was a triple threat featuring “Static Widow” Apryl Raser, Kiara Haddad, and Amber Sloane. All three women had high spots in this contest. Sloane nearly stole the win from Raser, after Raser hit Haddad with a knee drop and Amber jumped on Haddad. This led to shoving between Apryl and Amber. Haddad used this time to recover enough to knock Raser out of the ring with a dropkick and roll Amber up with a small package, getting the 1-2-3.


---

Brenda McHale was the unfortunate soul who had to interview Fox Kelly. Kelly looked like he just got out of bed and had a whiskey bottle in his hand. He hit on Brenda, then stated that Floyd was wasting his time with these tournaments, stating he will be the first Heavyweight Champion and his sister, Katie, would be the first Women’s Champion. A pre-taped video package of Too Sweet (Candi and Cookie) then played, drawing wolf whistles from the men. The young women claimed their stake to the Tag-Team titles and said they would be making their in-ring debut on the next Mayhem.

---

### 6-Way Match
#### Fox Kelly vs Frank Roberts vs Jamey Kingston vs Joe Shore vs Payne vs TJ Valentine

TJ Valentine, Jamey Kingston, “The Monster” Payne, Fox Kelly, “Foul “ Frank Roberts, and Joe Shore were all part of a huge 6-Way match. Payne came down to the ring carrying a kendo stick, and was not afraid to use it in this match that had no disqualification rules. That is, until “Foul” Frank took the kendo stick and broke it and followed this with a huge spear to Payne. Kingston squared off with Joe Shore, while Valentine mixed it up with Fox Kelly. The pairings switched a few times during this contest and no one was sparred some degree of punishment. The eventual winner, however, was Jamey Kingston after driving TJ Valentine hard into the canvas with a sit out powerbomb.

---

Backstage, Brenda McHale interviewed Rudy Fresno and Apalachi. Fresno defended his earlier actions against Tom Ham and talked up the Sacred Dragons prior to their match against the Happy Faces. Their was a backstage segment with Jim Brady, Rick Walker, and Rob Johnson, and one final segment with Brenda interviewing Jamey Kingston.

---

### Main Event - Tag-Team Match
#### The Happy Faces vs Sacred Dragons

The main event was between two of the highest anticipated tag-teams to join WMA as The Happy Faces faced off against the Sacred Dragons. This contest nearly hit the 20 minute time limit, but in the end, Jack and Sam pulled a fast one, winning the match by disqualification.