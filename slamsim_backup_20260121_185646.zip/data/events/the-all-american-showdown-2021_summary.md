### Tag Team #1 Contender Match
#### Knightfall (Chris Davids, John Blair) vs The Texas Badlanders (Frank Roberts,  Bill McGraw)

The All-American Showdown 2021 kicked off with a high-stakes Tag Team #1 Contender Match, featuring two teams intimately familiar with each other: Knightfall (Chris Davids and John Blair) and The Texas Badlanders (Frank Roberts and Bill McGraw). As the bell rang, a commentator noted, "A cloud hangs over Knightfall tonight with their manager, Shadowcat, reportedly at the hospital with an injured colleague. Yet, Davids and Blair look completely focused on this crucial bout."

The Texas Badlanders wasted no time in asserting their formidable power. Frank Roberts, a towering 6'6" and 290 lbs, used his brute strength to dominate the agile Chris Davids in the early going, throwing him around the ring with authority. Bill McGraw, equally imposing, delivered heavy forearms and a brutal sidewalk slam, isolating Davids in their corner. The Badlanders' brawling style was on full display, with quick tags and punishing double-team maneuvers, including a devastating double clothesline that crumpled Davids to the mat. John Blair, waiting for the tag, seethed on the apron, urging his partner on.

Eventually, Davids managed a desperate enziguri, creating just enough space to lunge for the tag. John Blair exploded into the ring, a force of nature with his brawler and striker styles. He met McGraw with a flurry of hard chops and a big boot, then turned his attention to Roberts on the apron, delivering a stiff forearm that sent "Foul" Frank reeling. Knightfall then synchronized perfectly, dropping McGraw with a powerful **Hammer to Fall**, their double DDT, leading to a near fall that the crowd believed was the end.

The Texas Badlanders, however, were relentless. Roberts, leveraging his size and strength, picked Davids up and slammed him down repeatedly before tagging in McGraw. The Badlanders then executed their signature high-low maneuver, **Sorry Bout Your Damn Luck**, on Davids. McGraw went for the cover, but Blair, always alert, dove in just in time to break up the pin, saving the match for his team. The pace quickened dramatically, with close pinfalls for both sides. Roberts delivered a spinebuster to Blair, only for Davids to respond with a flying crossbody.

As the match approached its 20-minute mark, exhaustion began to set in, but the intensity never wavered. Blair, employing his brawler instincts, engaged in a slugfest with McGraw in the center of the ring, getting the better of the exchange. Davids, meanwhile, launched himself from the top rope with a breathtaking plancha onto Roberts on the outside, then quickly slid him back into the ring only to hit **Swing Shift**, the dropsault cradle, sending Roberts out of the picture again.

With McGraw isolated, Knightfall moved in for the kill. Blair lifted McGraw into a powerbomb position, and Davids ascended the ropes, executing their devastating **We will Rock You** – a thunderous powerbomb/senton combo that rocked the arena. McGraw barely stirred. Blair then hooked McGraw, and with Davids joining him, delivered a final, impactful **Another One Bites the Dust**, their signature clothesline/spear combo. Blair immediately covered McGraw. The referee's hand hit the mat: one, two, three!

Knightfall secured the pinfall victory at 22 minutes and 38 seconds. Despite Shadowcat's absence, Davids and Blair proved their championship mettle, overcoming the hard-hitting Texas Badlanders in a truly hard-fought contest and earning their shot at the Tag Team Championships. They stood tall, a unified front, celebrating their hard-earned win as the crowd roared its approval.

---

### WMA Women's Championship
#### Katy Kelly vs Naomi Tanaka

Inaugural champion, Katy Kelly!

---

### WMA Tag-Team Championship
#### The Mad Dogs (Mad Dog Bark,  Mad Dog Bite) vs The Masked Crushers (Crusher #1, Crusher #2)

They beat the shit out of each other, but when firearms got involved, the ref called it off.

---

### Main Event - World Championship
#### Timothy Myers vs Scott Ashton

Slobberknocker! Myers with the pin!